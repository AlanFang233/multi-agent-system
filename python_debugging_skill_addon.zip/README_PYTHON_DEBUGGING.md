# Python Debugging Skill — installation and smoke test

This add-on supplies an English `python-debugging` Skill for the Coding Agent. It **does not overwrite** any existing project files. The Skill is a set of instructions; it does not grant permissions or execute code itself.

## 1. Install

From the project root:

```bash
unzip -n python_debugging_skill_addon.zip -d .
```

The new file should be:

```
skills/coding/python-debugging/SKILL.md
```

## 2. Register it

Edit **the existing** `config/agent_skills.yaml`, extending (not replacing) the Coding list:

```yaml
root: skills
agents:
  research:
    - evidence-synthesis
  coding:
    - git-audit
    - python-debugging
  analysis:
    - loss-analysis
```

The Registry loads the file only when the skill is listed. This project version rejects `SKILL.md` files longer than 10,000 characters; this Skill stays below that limit.

## 3. Activate the Skill

Option A — keep the existing Coding default (`git-audit`) and explicitly ask for the new Skill:

```bash
python -m agent_ecosystem.tool_agent --role coding --prompt \
  'First call skills:load with name=python-debugging. Then use the Python debugging workflow to reproduce and fix this bug in a new sandbox: calculator.py defines add(a,b) as a-b, while test_calculator.py expects add(2,3)==5. Run pytest before and after the change. Do not modify project source files.'
```

Expected tool sequence (ordering may vary):

```
skills:load
sandbox:create
filesystem_code:write_file
filesystem_code:write_file
sandbox:run_pytest       # first run: test failure
filesystem_code:edit_file
sandbox:run_pytest       # second run: test success
```

**Note:** Currently `tool_agent.py` auto-loads `git-audit` for all Coding tasks. Option A therefore loads both Skills during debugging; consider Option B for efficiency.

Option B — auto-select `python-debugging` for debugging prompts. In `ask_with_tools()` in `src/agent_ecosystem/tool_agent.py`, immediately after the existing line:

```python
skill_name = DEFAULT_SKILLS.get(role)
```

add:

```python
if role == "coding" and any(
    marker in prompt.lower()
    for marker in (
        "debug", "bug", "traceback", "pytest", "exception",
        "fix", "regression", "调试", "报错", "修复", "测试失败",
    )
):
    skill_name = "python-debugging"
```

This is a simple deterministic router, not a full task classifier. It preserves `git-audit` for other Coding tasks. Restart A2A servers after changing code or configuration.

## 4. Validate without an LLM

```bash
source .venv/bin/activate
python -m pytest -q tests/test_python_debugging_skill.py
```

The test validates the Skill metadata, Registry size constraints, and required operational instructions. It does **not** prove that the agent has the tools or that the Docker sandbox works.

## 5. Test the actual sandbox

Ensure Docker Engine is running, `sandbox:create`, `sandbox:run_pytest`, and authorized Filesystem tools are available to Coding, then run the prompt in section 3. The first pytest run should fail, and the second should pass. Inspect the **actual** MCP results rather than accepting a narrative claim.

## Security

Only use the sandbox work directory for experiments. The standalone Skill does not grant access to `src/`, secrets, Docker socket, or Git write operations. Restrict those separately through MCP permissions and operating-system/container isolation.
